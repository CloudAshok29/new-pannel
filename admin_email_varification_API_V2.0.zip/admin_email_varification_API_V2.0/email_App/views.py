from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics
from django.core.mail import send_mail
import random
from django.conf import settings
from .models import CustomUser
from rest_framework import status
from django.contrib.auth import login
from django.views.decorators.csrf import csrf_protect

from django.core.cache import cache
# from django.views import View

# Create your views here.
class RegisterAPI(generics.GenericAPIView):
    serializer_class = UserSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response({
        "user": UserSerializer(user, context=self.get_serializer_context()).data
        })




def generateOTP(email) :
    """
    function to generate OTP
    """
    time = 180
    otp_key = email
    OTP = cache.get(otp_key)
    if not OTP:
        OTP = str(random.randint(100000,999999))
        cache.set(otp_key, OTP, time)
    return OTP,time



def verifyOTP(email,OTP):
    """
    function to verify OTP
    """



    otp_key = email
    return cache.get(otp_key) == OTP


class Send_OTP(APIView):

    def post(self, request):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.data['email']
            user = CustomUser.objects.filter(email=email)
            if user.exists():
                subject = "Your Account Varification Mail."
                # otp = random.randint(1000, 9999)
                # request.session['otp'] = otp
                otp, valid_for = generateOTP(email)
                message = f"WELCOME TO SHIVILA TECHNOLOGIES PRIVATE LIMITED.\n\nDear admin,\n\n\nYour account varification code is {otp}"
                email_from = settings.EMAIL_HOST_USER
                send_mail(subject, message, email_from, [email])
            
            return Response({
                    'status':200,
                    'message':'OTP sent',
                    })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class Log_In(APIView):

    def post(self, request):

        data = request.data

        serializer = varifyAccountSerializer(data=data)

        if serializer.is_valid():
            email = serializer.data['email']
            otp = serializer.data['otp']

            user = CustomUser.objects.filter(email=email)

            if not user.exists():
                return Response({
                    'status':400,
                    'message':'Something went wrong',
                    'data':'Invalid email',
                    'otp': otp
                    })
                    
            user = user.first()
            if verifyOTP(email,otp):
                user.is_verified = True
                user.save()
                return Response({"msg":"otp verified"},status=status.HTTP_200_OK)
            else:
                return Response({
                "msg" : "OTP not valid or OTP has expired."}, status=status.HTTP_400_BAD_REQUEST)
          
