from rest_framework import serializers
from .models import CustomUser
from django.contrib.auth import authenticate
from django.utils.translation import gettext_lazy as _


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ('id', 'email', 'is_varified', 'password')

        def validate(self, data):
            if not data.get('email'):
                raise serializers.ValidationError("Please enter a email.")
            if not data.get('password'):
                raise serializers.ValidationError("Please enter a password.")
            return data


        def create(self, validated_data):
            user = CustomUser(
                            email=validated_data['email'],
                         )
            user.set_password(validated_data['password'])
            user.save()
            # send_otp_via_mail(validated_data['email'])
            return user


class CustomUserSerializer(serializers.Serializer):
    email = serializers.EmailField()

    def validate(self, data):
        print(data)
        if not data.get('email'):
            raise serializers.ValidationError("Please enter a email.")
        if data.get('email') not in [ "debanka.das@shivila.com", "suraj.mahakud@shivila.com","sayantan.halder@shivila.com","kamalika.jash@shivila.com"]:  
            raise serializers.ValidationError("Invalid Email Address.")

        return data

class varifyAccountSerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField()


#Overriding AuthTokenSerializer

class AuthTokenSerializer(serializers.Serializer):
    email = serializers.CharField(
        label=_("email"),
        write_only=True
    )
    password = serializers.CharField(
        label=_("password"),
        style={'input_type': 'password'},
        trim_whitespace=False,
        write_only=True
    )
    otp = serializers.CharField(
        label=_("otp"),
        read_only=True
    )

    def validate(self, attrs):
        email = attrs.get('email')
        password = attrs.get('password')

        if email and password:
            user = authenticate(request=self.context.get('request'),
                                email=email, password=password)

            # The authenticate call simply returns None for is_active=False
            # users. (Assuming the default ModelBackend authentication
            # backend.)
            if not user:
                msg = _('Unable to log in with provided credentials.')
                raise serializers.ValidationError(msg, code='authorization')
        else:
            msg = _('Must include "email" and "password".')
            raise serializers.ValidationError(msg, code='authorization')

        attrs['user'] = user
        return attrs