from django.contrib import admin
from django.urls import path
from email_App.views import RegisterAPI, Send_OTP, Log_In
from email_App import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', RegisterAPI.as_view(), name='register'),
    path('send/', Send_OTP.as_view(), name='send'),
    path('verify/', Log_In.as_view(), name='verify'),
]

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('admin-register/', RegisterAPI.as_view(), name='register'),
#     path('admin-send/', views.Send_OTP, name='send'),
#     path('admin-verify/', views.Log_In, name='verify'),
# ]