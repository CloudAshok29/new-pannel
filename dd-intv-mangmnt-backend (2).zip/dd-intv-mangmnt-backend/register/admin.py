from django.contrib import admin
from .models import Registration


@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    fields = ( 'email','name','designation','status','interviewer_link')


