from .models import Candidate_details
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import Candidate_detailsSerializer


class Candidate_detailsViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows candidate to be viewed or edited.
    """
    queryset = Candidate_details.objects.all()
    serializer_class = Candidate_detailsSerializer
    permission_classes = [permissions.AllowAny]