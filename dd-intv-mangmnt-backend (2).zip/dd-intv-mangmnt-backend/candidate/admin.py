from django.contrib import admin
from .models import Candidate_details
#from .models import Contact

@admin.register(Candidate_details)
class Candidate_detailsAdmin(admin.ModelAdmin):
    fields = ('name_of_the_candidate','email','mobile_number','applied_domain','remarks','status','interviewer_name','interview_taken_time')


"""@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    fields = ('full_name','email','description')"""
